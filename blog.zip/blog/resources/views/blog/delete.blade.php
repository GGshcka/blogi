@extends("layouts.main")
@section("template")
    <div class="container">
        <form method="POST" action="{{ route('blog.api.delete', ['post_id' => $post->id]) }}">
            <input type="hidden" name="_method" value="DELETE">
            <h1>Do you want to delete a post {{ $post->title }}?</h1>
            <a href="/" class="btn btn-primary">Cancel</a>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    </div>
@stop