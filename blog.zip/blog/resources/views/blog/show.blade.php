@extends("layouts.main")
@section("template")
    <div class="container">
        <div class="content">
            <h1> {{$post->title}} </h1>
            <div> {{$post->created_at}} </div>
            <p> {{$post->content}} <p>
        </div>
    </div>
@stop