<?php
namespace App\Http\Controllers\Blog\Api;
use Laravel\Lumen\Routing\Controller as BaseController;
use illuminate\Http\Request;
use App\Models\Blog;
use App\Http\Controllers\Media\MediaController;

class BlogController extends BaseController {
    protected $blog;
    public function __construct(){
        $this->blog = new Blog;
    }
    public function index() {
        $posts = $this->blog->all();
        return response()->json($posts);
    }
    protected function fileHandLing(Request $request) {
        $data = $request->all();
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $media = app(MediaController::class)->createFile($file);
            $data['media_id'] = $media->id;
        }
        return $data;
    }
    public function create(Request $request) {
        $data = $this->fileHandLing($request);
        $this->blog->file($data);
        $this->blog->save();
        //return response()->json($blog);
        return redirect()->route('blog.index');
    }
    public function show($id) {
        $post = $this->blog->find($id);
        return response()->json($blog);
    }
    public function update(Request $request, $id) {
        $data = $this->fileHandling($id);
        $post = $this->blog->find($id);
        $post->fill($data);
        $poat->save();
        //return response()->json($blog);
        return redirect()->route('blog.index');
    }
    public function delete($id) {
        $post = $this->blog->destroy($id);
        return redirect()->route('blog.index');
    }
}