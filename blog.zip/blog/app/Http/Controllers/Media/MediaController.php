<?php
namespace App\Http\Controllers\Media;
use Laravel\Lumen\Routing\Controller as BaseController;
use Illuminate\Support\Facades\File;
use App\Models\Media;
use Illuminate\Http\Request;

class MediaController extends BaseController {
    protected $storage;

    public function __construct(){
        $this->storage = app('filesystem');
    }
    public function show($imagePath) {
        if($this->storage->exists($imagePath)) {
            $file = $this->storage->get($imagePath);
            return response($file, 200, ['Content-Type' => $this->storage->mimeType($imagePath)]);
        }
        else {
            abort(404);
        }
        
    }
    public function createFile($file) {
        $dataFile = $this->uploadFile($file);
        $media = new Media;
        $media->fill($dataFile);
        $media->save();
        return $media;
    }
    protected function uploadFile($file){
        $name = $file->getClientOriginalExtention();
        $realPath = $file->getRealPath();
        $size = $file->getSize();
        $newName = $this->uniqueName($realPath);
        $newPath = $this->makePath($newName,$extention);
        $content = File::get($realPath);
        $this->storage->put($newPath,$content);
      
        return [
          'name'=>$name,
          'extention'=>$extention,
          'path'=>$newPath,
          'size'=>$size,
        ];
    }
      
    protected function uniqueName($path){
        return md5(md5file($path).(time().''.rand(1,5000)));
      
    }
    protected function makePath($newName,$extention){
        $this->storage->makeDirectory(substr($newName,0,2));
        $this->storage->makeDirectory(substr($newName,0,2).'/'.substr($newName,2,2));
        $newPath = substr($newName,0,2).'/'.substr($newName,2,2).'/'.$newName.'.'$extention;
        return $newPath;
    }
}

