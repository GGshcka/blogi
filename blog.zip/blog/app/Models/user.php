<?php
namespace App\Models;

use Illuminate\Database\Elquent\Model;

class User extends Model {
    protected $table = "user";
    protected $fillable = [
        'name', 'surename', 'email',
    ];
    protected $hidden = [
        'password',
    ];
}