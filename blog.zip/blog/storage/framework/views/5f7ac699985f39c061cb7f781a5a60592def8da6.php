<?php $__env->startSection("template"); ?>
    <div class="container">
        <div class="content">
            <h1> <?php echo e($post->title); ?> </h1>
            <div> <?php echo e($post->created_at); ?> </div>
            <p> <?php echo e($post->content); ?> <p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\OSPanel\domains\blog\resources\views/blog/show.blade.php ENDPATH**/ ?>