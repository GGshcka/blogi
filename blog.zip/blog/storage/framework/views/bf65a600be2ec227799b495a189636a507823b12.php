<?php $__env->startSection("template"); ?>
    <div class="container">
        <div class="row pt-5">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-col-md-6 col-lg-4 pb-5">
                <div class="card">
                    <img class="card-img-top" src="/media/storage/<?php echo e($post->path); ?>" alt="<?php echo e($post->title); ?>">
                    <div class="card-body">
                        <a class="card-title" href="<?php echo e(route('blog.show', ['post_id'=>$post->id])); ?>"> <?php echo e($post->title); ?> </a>
                        <p class="card-text"> <?php echo e($post->description); ?> </p>
                        <a class="btn btn-primary" href="<?php echo e(route('blog.edit', ['post_id'=>$post->id])); ?>" role="button"> Edit post </a> 
                        <a class="btn btn-danger" href="<?php echo e(route('blog.delete', ['post_id'=>$post->id])); ?>" role="button"> Delete post </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\OSPanel\domains\blog\resources\views/blog/index.blade.php ENDPATH**/ ?>