<?php $__env->startSection("template"); ?>
    <div class="container">
        <form method="POST" action="<?php echo e(route('blog.api.delete', ['post_id' => $post->id])); ?>">
            <input type="hidden" name="_method" value="DELETE">
            <h1>Вы хотите удалить пост <?php echo e($post->title); ?>?</h1>
            <a href="/" class="btn btn-primary">Отмена</a>
            <button type="submit" class="btn btn-danger">Удалить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Server\OSPanel\domains\blog\resources\views/blog/delete.blade.php ENDPATH**/ ?>