<?php
$router->group([
    'prefix' => 'media',
    'namespace' => 'media'    
], function($router) {
    $router->get('/storage/{image:.*?}', [
        'as' => 'media.show',
        'uses' => 'MediaController@show'
    ]);
});